package model;

public class HashTable<T,U> implements InterfaceHT<T,U>{
	
	public HashTable(int a) {
		super();
	}

	@Override
	public void insert(T key, U value) throws Exception {
		
	}

	@Override
	public U search(T key) {
		
		return null;
	}

	@Override
	public void deleteKey(T key) {
		
		
	}

}
