package model;

public class Patient {

}
